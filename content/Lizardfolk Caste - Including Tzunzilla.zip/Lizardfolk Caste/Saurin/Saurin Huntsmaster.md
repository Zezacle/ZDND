---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Huntsmaster
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 20 **Initiative** +10 (20)
> **HP** 209 (22d8 + 110)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +10 | **INT** | 14 | +2 | +2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 20 | +5 | +10 | 
> | **CON** | 20 | +5 | +10 | **CHA** | 13 | +1 | +6 |
> 
> | |
> | - |
> **Skills** Nature +7, Perception +10, Survival +15
> **Gear** Maul, Shield
> **Resistances** Bludgeoning, Piercing, Slashing
> **Immunities** Acid, Poison; Charmed, Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 20
> **Languages** Primordial (Terran)
> **CR** 13 (XP 10,000; PB +5)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold their breath for an hour.

***Legendary Resistance (3/Day).*** If the saurin fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

### Actions
***Multiattack.*** The saurin makes three attacks.

***Forceful Maul.*** *Melee Attack Roll:* +10 to hit, reach 5 ft. _Hit:_ 21 (3d10 + 5) force damage and the target is pushed 15 feet away from the saurin and lands [[prone]]. The saurin may then move up to half its Speed straight toward the target without provoking [[Opportunity Attacks]].

***Boiling Bite.*** *Melee Attack Roll:* +10 to hit, reach 5 ft. _Hit:_ 21 (3d10 + 5) acid damage. If the target is a creature that isn’t a Construct or an Undead, the saurin gains Temporary Hit Points equal to the damage dealt.

***Earth Fetch.*** *Ranged Attack Roll:* +10 to hit, range 60 ft. _Hit:_ 21 (3d10 + 5) bludgeoning damage and the target is moved 30 feet towards the saurin.

***Spit Poison.*** *Ranged Attack Roll:* +10 to hit, range 60 ft. _Hit:_ 21 (3d10 + 5) poison damage.

### Bonus Action
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.

### Legendary Actions
*Legendary Action Uses: 3. Immediately after another creature’s turn, the saurin can expend a use to take one of the following actions. The saurin regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Rushing Charge (1/Round).*** The saurin moves up to its Speed without provoking [[Opportunity Attacks]] and can move through the spaces of Medium or smaller creatures. Each creature whose space the saurin enters is targeted once by the following effect. *Strength Saving Throw:* DC 18. *Failure:* 21 (3d10 + 5) bludgeoning damage, and the target is knocked [[prone]]. *Success:* Half damage only.

***Relentless Attacks.*** The saurin moves up to its speed and makes an attack.

