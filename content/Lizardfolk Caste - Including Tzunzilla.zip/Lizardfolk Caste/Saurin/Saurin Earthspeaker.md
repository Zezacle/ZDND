---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Earthspeaker
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +3 (13)
> **HP** 110 (13d8 + 52)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +7 | **INT** | 7 | -2 | -2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 19 | +4 | +7 | 
> | **CON** | 18 | +4 | +7 | **CHA** | 7 | -2 | -2 |
> 
> | |
> | - |
> **Skills** Nature +4, Perception +7, Survival +10
> **Resistances** Bludgeoning, Piercing, Slashing
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 17
> **Languages** Primordial (Terran)
> **CR** 7 (XP 2,900; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold its breath for an hour.

### Actions
***Nourishing Bite.*** *Melee Attack Roll:* +7 to hit, reach 5 ft. _Hit:_ 13 (2d8 + 4) piercing damage. If the target is a creature that isn’t a Construct or an Undead, the saurin gains Temporary Hit Points equal to the damage dealt.

***Bend Earth (Recharge 5-6).*** *Dexterity Saving Throw:* DC 15, each creature in a 20-foot-radius sphere centered on a point the lizardfolk can see within 60 feet. *Failure:* The target takes 28 (8d6) bludgeoning damage and is knocked [[prone]]. *Success:* Half damage only.

***Spellcasting.*** The saurin casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 15):

**At Will:** [[Speak with Plants]], [[Speak with Animals]], [[Elementalism]]
**2/Day Each:**  [[Heat Metal]] (level 5 version), [[Hold Person]] (level 4 version)
**1/Day Each:** [[Earthquake]]

### Bonus Action
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.