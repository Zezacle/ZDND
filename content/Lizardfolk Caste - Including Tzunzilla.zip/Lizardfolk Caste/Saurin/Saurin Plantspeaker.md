---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Plantspeaker
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +0 (10)
> **HP** 65 (10d8 + 20)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 16 | +3 | +3 | **INT** | 7 | -2 | -2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 16 | +3 | +5 | 
> | **CON** | 15 | +2 | +2 | **CHA** | 7 | -2 | -2 |
> 
> | |
> | - |
> **Skills** Nature +2, Perception +5, Survival +7
> **Gear** Morningstar, Shield
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 3 (XP 700; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold their breath for an hour.

### Actions
***Spiked Club.*** *Melee Attack Roll:* +5 to hit, reach 5 ft. _Hit:_ 8 (1d10 + 3) piercing damage.

***Spellcasting.*** The saurin casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 13):

**At Will:** [[Speak with Plants]], [[Speak with Animals]], [[Elementalism]]
**2/Day Each:**  [[Heat Metal]], [[Hold Person]]
**1/Day Each:** [[Plant Growth]], [[Spike Growth]]

### Bonus Actions
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.