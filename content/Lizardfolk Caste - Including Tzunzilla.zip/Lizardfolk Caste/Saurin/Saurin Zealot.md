---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Zealot
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +3 (13)
> **HP** 110 (13d8 + 52)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +7 | **INT** | 7 | -2 | -2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 16 | +3 | +6 | 
> | **CON** | 18 | +4 | +7 | **CHA** | 7 | -2 | -2 |
> 
> | |
> | - |
> **Skills** Perception +6, Religion +4, Survival +9
> **Gear** Maul
> **Immunities** Acid, Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 16
> **Languages** Primordial (Terran)
> **CR** 6 (XP 2,300; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold its breath for an hour.

### Actions
***Multiattack.*** The saurin makes two attacks. It can replace one attack with a use of Spellcasting.

***Earthen Maul.*** *Melee Attack Roll:* +7 to hit, reach 5 ft. _Hit:_ 13 (2d8 + 4) piercing damage.

***Spit Poison.*** *Ranged Attack Roll:* +7 to hit, range 60 ft.. _Hit:_ 11 (2d6 + 4) poison damage.

***Spellcasting.*** The gecks casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 14):

**At Will:** [[Speak with Plants]], [[Speak with Animals]], [[Elementalism]]
**2/Day Each:**  [[Bestow Curse]], [[Remove Curse]]
**1/Day Each:** [[Spirit Guardians]], [[Silence]]

### Bonus Actions
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.

***Zealotry.*** When the saurin hits a creature with a melee attack, it deals an extra 21 (6d6) acid damage.