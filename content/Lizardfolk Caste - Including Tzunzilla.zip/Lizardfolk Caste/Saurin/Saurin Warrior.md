---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Warrior
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +0 (10)
> **HP** 26 (4d8 + 8)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 16 | +3 | +3 | **INT** | 7 | -2 | -2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +1 | 
> | **CON** | 15 | +2 | +2 | **CHA** | 7 | -2 | -2 |
> 
> | |
> | - |
> **Skills** Perception +3, Survival +5
> **Gear** Morningstar, Handaxe (6), Shield
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 13
> **Languages** Primordial (Terran)
> **CR** 1 (XP 200; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold its breath for an hour.

### Actions
***Spiked Club.*** *Melee Attack Roll:* +5 to hit, reach 5 ft. _Hit:_ 8 (1d10 + 3) piercing damage.

***Bone Axe.*** *Melee or Ranged Attack Roll:* +5 to hit, reach 5 ft. or range 20/60 ft.. _Hit:_ 6 (1d6 + 3) piercing damage.

### Bonus Actions
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.