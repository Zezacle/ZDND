---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Saurin Rampager
> *Medium Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +3 (13)
> **HP** 110 (13d8 + 52)
> **Speed** 30 ft., swim 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +7 | **INT** | 7 | -2 | -2 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +1 | 
> | **CON** | 18 | +4 | +7 | **CHA** | 7 | -2 | -2 |
> 
> | |
> | - |
> **Skills** Perception +4, Survival +7
> **Resistances** Bludgeoning, Piercing, Slashing
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 14
> **Languages** Primordial (Terran)
> **CR** 6 (XP 2,300; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The saurin can hold its breath for an hour.

### Actions
***Multiattack.*** The saurin makes two attacks.

***Nourishing Bite.*** *Melee Attack Roll:* +7 to hit, reach 5 ft. _Hit:_ 13 (2d8 + 4) piercing damage. If the target is a creature that isn’t a Construct or an Undead, the saurin gains Temporary Hit Points equal to the damage dealt.

***Spit Poison.*** *Melee or Ranged Attack Roll:* +7 to hit, reach 5 ft., range 60 ft.. _Hit:_ 11 (2d6 + 4) poison damage.

### Bonus Actions
***Group Predator.*** The saurin makes a melee attack against a creature that is within 5 feet of another creature that is allied to the saurin and not incapacitated.