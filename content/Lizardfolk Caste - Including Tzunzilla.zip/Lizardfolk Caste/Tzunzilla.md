---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Tzunzilla, the Dead Titan
> *Gargantuan Undead, Chaotic Evil*
> 
> | |
> | - |
> **AC** 24 **Initiative** +17 (27)
> **HP** 560 (34d20 + 340)
> **Speed** 60 ft., Climb 60 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 30 | +10 | +10 | **INT** | 6 | -2 | -2 | 
> | **DEX** | 13 | +1 | +1 | **WIS** | 14 | +2 | +2 | 
> | **CON** | 30 | +10 | +10 | **CHA** | 11 | +0 | +8 | 
>  
> | |
> | - |
> **Skills** Athletics +18, Intimidation +8, Perception +10, Survival +18
> **Resistance** Bludgeoning, Piercing, Slashing, Poison, Acid, Thunder
> **Immunity** Charmed, Frightened, Stunned
> **Senses** Blindsight 120 ft., Passive Perception 20
> **Languages** Terran
> **CR** 27 (XP 105,000; PB +8)
> 
> | |
> | - |

### Traits
***Legendary Resistance (6/Day).*** If Tzunzilla fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
 
***Magic Resistance.*** Tzunzilla has Advantage on saving throws against spells and other magical effects.

***Siege Monster.*** Tzunzilla deals double damage to objects and structures.

***Undead Fortitude.*** If damage reduces Tzunzilla to 0 Hit Points, it makes a Constitution saving throw (DC 5 plus the damage taken) unless the damage is radiant or from a Critical Hit. On a successful save, Tzunzilla drops to 1 Hit Point instead.

***Undying Titan (1/Day Mythic Trait).*** If Tzunzilla would be reduced to 0 hit points, its current hit point total instead resets to its maximum hit points and it regains any expended uses of Legendary Resistance. It recharges Radiant Roar and uses it immediately.

### Actions
***Multiattack.*** Tzunzilla makes three attacks.

***Rend.*** *Melee Attack Roll*: +18, reach 15 ft. Hit: 36 (4d12 + 10) slashing damage.

### Bonus Actions
***Restraining Grapple.*** *Dexterity Saving Throw:* DC 26, each creature in a 90-foot cone. *Failure*: 91 (26d6) radiant damage and the creature is blinded until the end of its next turn. *Success:* Half damage only.

***Thundering Roar.*** *Constitution Saving Throw:* DC 26, each creature in a 600-foot Emanation. *Failure:* 26 (4d12) thunder damage and the creature is deafened for 1 minute. *Success:* Half damage only.

### Reactions
***Impenetrable Hide.*** *Trigger:* Tzunzilla is damaged by an attack roll. *Response:* Tzunzilla reduces the incoming damage by 22 (4d10).

### Legendary Actions
*Legendary Action Uses: 4. Immediately after another creature’s turn, Tzunzilla can expend a use to take one of the following actions. Tzunzilla regains all expended uses at the start of each of his turns.*

***World-Shaking Movement (1/Round).*** Tzunzilla moves up to its speed. At the end of its movement, Tzunzilla creates an instantaneous shock wave in a 60-foot Emanation originating from itself. Creatures in that area lose Concentration and, if medium or smaller, fall prone.

***Onslaught.*** Tzunzilla moves up to half its speed, and makes a rend attack.

### Mythic Actions
*The following legendary actions can be used for 1 Hour after the Mythic Trait has been activated*

***Tail Swipe (1/Round).*** *Dexterity Saving Throw:* DC 26, each creature in a 30-foot Emanation. *Failure:* 26 (4d12) bludgeoning damage. *Success:* Half damage.

***Bounding Leap (1/Round).*** Tzunzilla leaps to a location within 100 feet. Creatures within 10 feet of where Tzunzilla landed are immediately knocked prone. Tzunzilla can then make a rend attack.