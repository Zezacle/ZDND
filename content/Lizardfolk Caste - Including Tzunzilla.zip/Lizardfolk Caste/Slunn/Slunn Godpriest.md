---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Slunn Godpriest
> *Large Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +8 (18)
> **HP** 171 (18d10 + 72)
> **Speed** 15 ft., fly 30 ft. (hover)
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 16 | +3 | +3 | **INT** | 18 | +4 | +4 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 23 | +6 | +10 | 
> | **CON** | 18 | +4 | +8 | **CHA** | 16 | +3 | +3 |
> 
> | |
> | - |
> **Skills** Nature +8, Perception +10
> **Immunities** Poison; Charmed, Frightened, Poisoned, Prone
> **Senses** Truesight 60ft., Darkvision 60 ft., Passive Perception 20
> **Languages** Primordial (Terran)
> **CR** 11 (XP 7,200; PB +4)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The slunn can hold its breath for an hour.

### Actions
***Multiattack.*** The slunn makes two Blighting Curse attacks.

***Blighting Curse.*** *Melee or Ranged Attack Roll:* +10 to hit, reach 5 ft., range 60 ft. *Hit:* 19 (3d8 + 6) necrotic damage and the target becomes [[Poisoned]] until the end of its next turn.

***Spellcasting.*** The slunn casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 18):

**At Will:** [[Hold Monster]], [[Control Weather]], [[Transport via Plants]], [[Polymorph]], [[Call Lightning]]
**3/Day Each:**  [[Befuddlement]], [[Insect Plague]], [[Contagion]]
**1/Day Each:** [[Reverse Gravity]], [[Storm of Vengeance]]

### Bonus Actions
***Transfer Concentration.*** The slunn magically transfers the concentration of a spell it's concentrating on to an allied creature with the spellcasting feature that is within 120 feet of the slunn. That creature must now maintain concentration on that spell instead of the slunn.

### Legendary Actions
*Legendary Action Uses: 4. Immediately after another creature’s turn, the slunn can expend a use to take one of the following actions. The slunn regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Acid Rain (1/Round).*** *Constitution Saving Throw:* DC 18, creatures in a 20-foot radius sphere originating at a point the slunn can see. *Failure:* The target takes 18 (4d8) acid damage. *Success:* Half damage only.

***Lightning Strike.*** *Dexterity Saving Throw:* DC 18, a creature the slunn can see within 100 feet. *Failure:* The target takes 27 (6d8) lightning damage. *Success:* Half damage only. *Success or Failure:* Creatures within 10 feet of the target take 9 (2d8) lightning damage.

***Poisoned Earth.*** All creatures on the ground in a 200-foot [[Emanation]] take 7 (2d6) poison damage.

***Flight of Blight.*** The slunn moves up to its speed and uses Blighting Curse.