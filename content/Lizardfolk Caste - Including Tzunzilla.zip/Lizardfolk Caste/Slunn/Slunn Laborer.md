---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Slunn Laborer
> *Large Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +8 (18)
> **HP** 7 (2d8 - 2)
> **Speed** 15 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 14 | +2 | +4 | **INT** | 8 | -1 | -1 |
> | **DEX** | 7 | -2 | -2 | **WIS** | 7 | -2 | -2 | 
> | **CON** | 9 | -1 | -1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Immunities** Poison; Poisoned, Frightened
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 1/8 (XP 25; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The slunn can hold their breath for an hour.

### Actions
***Claw.*** *Melee Attack Roll:* +4 to hit, reach 5 ft., *Hit:* 5 (1d6 + 2) slashing damage.