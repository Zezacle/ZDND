---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gorek Warchief
> *Large Elemental, Neutral*
> 
> | |
> | - |
> **AC** 20 **Initiative** +8 (17)
> **HP** 252 (24d10 + 120)
> **Speed** 50 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 23 | +6 | +11 | **INT** | 4 | -3 | -3 |
> | **DEX** | 17 | +3 | +3 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 20 | +5 | +10 | **CHA** | 6 | -2 | -2 | 
> 
> | |
> | - |
> **Gear** Greatclub
> **Resistances** Acid
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 13 (XP 8,400; PB +5)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gorek can hold its breath for an hour.

***Implacable.*** The gorek cannot be forcibly moved against its will by any spell, attack, or ability, unless it is [[incapacitated]].

***Legendary Resistance (3/Day).*** If the gorek fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

### Actions
**Multiattack.** The gorek makes four attacks.

***Two-Headed Club.*** *Melee Attack Roll:* +11, reach 10 ft. *Hit:* 15 (2d8 + 6) bludgeoning damage and the gorek makes another attack against a different creature that is within its reach, and within 5 feet of the target. It can only make this additional attack once per turn.

***Tail Whip.*** *Melee Attack Roll:* +11, reach 10 ft. *Hit:* 15 (2d8 + 6) bludgeoning damage and the target is knocked [[prone]].

### Bonus Actions
***Primordial Roar (2/Day).*** *Wisdom Saving Throw:* DC 18, each creature in a 30-foot [[Emanation]] originating from the gorek. *Failure:* The target is [[Frightened]] until the end of the gorek's next turn. While a creature is frightened in this way, the gorek and its allies have [[Advantage]] on attack rolls against that creature.

### Reactions
***Hulk.*** *Trigger:* The gorek is hit by an attack. *Response:* The gorek reduces the incoming damage by 10 (1d10 + 5). If this reduces the damage to 0, the gorek may make a tail whip attack.

### Legendary Actions
*Legendary Action Uses: 3. Immediately after another creature’s turn, the gorek can expend a use to take one of the following actions. The gorek regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Spew Acid (1/Round).*** *Dexterity Saving Throw:* DC 18, each creature in a 15 foot cone. Failure: 49 (14d6) Acid damage. Success: Half damage.

***Drop Them (1/Round).*** The gorek moves up to its speed. Every creature within 10 feet of the gorek as it moves must make a DC 18 Dexterity Saving Throw or take 15 (2d8 + 6) bludgeoning damage and fall prone.

***Club Flurry.*** The gorek makes a Two-Headed Club attack.