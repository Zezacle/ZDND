---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gorek Beast
> *Large Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +1 (11)
> **HP** 92 (11d10 + 32)
> **Speed** 50 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +7 | **INT** | 4 | -3 | -3 |
> | **DEX** | 12 | +1 | +1 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 16 | +3 | +6 | **CHA** | 6 | -2 | -2 | 
> 
> | |
> | - |
> **Gear** Greatclub
> **Resistances** Acid
> **Immunities** Poison; Frightened, Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 5 (XP 1,800; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gorek can hold its breath for an hour.

***Implacable.*** The gorek cannot be forcibly moved against its will by any spell, attack, or ability, unless it is [[incapacitated]].

### Actions
**Multiattack.** The gorek makes two attacks.

***Two-Headed Club.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 13 (2d8 + 4) bludgeoning damage and the gorek makes another attack against a different creature that is within its reach, and within 5 feet of the target. It can only make this additional attack once per turn.

***Tail Whip.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 13 (2d8 + 4) bludgeoning damage and the target is knocked [[prone]].

### Bonus Actions
***Primordial Roar (1/Day).*** *Wisdom Saving Throw:* DC 14, each creature in a 30-foot [[Emanation]] originating from the gorek. *Failure:* The target is [[Frightened]] until the end of the gorek's next turn. While a creature is frightened in this way, the gorek and its allies have [[Advantage]] on attack rolls against that creature.

### Reactions
***Hulk.*** *Trigger:* The gorek is hit by an attack. *Response:* The gorek reduces the incoming damage by 8 (1d10 + 3). If this reduces the damage to 0, the gorek may make a tail whip attack.