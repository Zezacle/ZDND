Lizardfolk is a collection of species;

### Gecks
SSDS

- [[Gecks Raider]] (CR 1/8)
- [[Gecks Stalker]] (CR 1/2)
- [[Gecks Catcher]] (CR 2)
- [[Gecks Seer]] (CR 5)
- [[Gecks Skypriest]] (CR 10)

### Chamilon
Chameleon no dis on prone, chameloen stealth

- [[Chamilon Bolas]]  (CR 1/2)
- [[Chamilon Hunter]] (CR 1)
- [[Chamilon Skirmisher]] (CR 3)
- [[Chamilon Elder]] (CR 6)

### Gorek
Towering reptilian titans bred for battle, Kroxigors are the muscle and shock troopers of the Quexil Cast. They are single-minded but fiercely loyal, moving with terrifying momentum and striking with earthshaking force.

* [[Gorek Beast]] (CR 5)
* [[Gorek Hulk]] (CR 9)
* [[Gorek Warchief]] (CR 12)

### Slunn
Slunn fly + big spells

- [[Slunn Laborer]] (CR 1/8)
- [[Slunn Godpriest]] (CR 11)

### Saurin
Saurin Charge + immune to fear + warrior has options, vanguards charge, earthspeaker aoe, zealot is paladin

- [[Saurin Warrior]] (CR 1)
- [[Saurin Charger]] (CR 3)
- [[Saurin Plantspeaker]] (CR 3)
- [[Saurin Zealot]] (CR 6)
- [[Saurin Rampager]] (CR 6)
- [[Saurin Earthspeaker]] (CR 7)
- [[Saurin Huntsmaster]] (CR 13)

### Dinosaurs
dinos flyby, swallow, roar, steal
big ones; siege engines, engineers, rampage

- [[Pterradyll]] (CR 1/2)
- [[Sprintadon]] (CR 1)
- [[Shriek Raptor]] (CR 2)
- [[Spine Raptor]] (CR 3)
- [[Securidon]] (CR 6)
- [[Dieseradon]] (CR 6)
- [[Blood Raptor]] (CR 8)