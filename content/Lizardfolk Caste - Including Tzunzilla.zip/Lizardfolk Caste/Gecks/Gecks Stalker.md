---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gecks Stalker
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 14 **Initiative** +2 (12)
> **HP** 5 (2d6 - 2)
> **Speed** 40 ft., climb 40 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 9 | -1 | -1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Gear** Blowgun, Javelin
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 1/4 (XP 50; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gecks can hold its breath for an hour.

### Actions
***Pointy Stick.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 30/120 ft.  _Hit:_ 4 (1d4 + 2) piercing damage.

***Spit Blowgun.*** *Ranged Attack Roll:* +4, range 25/100 ft. _Hit:_ 3 (1+2) piercing damage plus 5 (2d4) poison damage, and the target is [[poisoned]] until the end of its next turn.

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the gecks hits or misses. *Response:* The gecks moves up to its [[speed]] without provoking [[Opportunity Attacks]].