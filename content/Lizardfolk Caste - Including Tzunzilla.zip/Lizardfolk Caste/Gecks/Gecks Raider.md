---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gecks Raider
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +2 (12)
> **HP** 5 (2d6 - 2)
> **Speed** 40 ft., climb 40 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 7 | -2 | -2 | 
> | **CON** | 9 | -1 | -1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Gear** Javelin (9), Shield
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 8
> **Languages** Primordial (Terran)
> **CR** 1/8 (XP 25; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gecks can hold its breath for an hour.

### Actions
***Pointy Stick.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 30/120 ft.  _Hit:_ 4 (1d4 + 2) piercing damage.

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the gecks hits or misses. *Response:* The gecks moves up to its [[speed]] without provoking [[Opportunity Attacks]].