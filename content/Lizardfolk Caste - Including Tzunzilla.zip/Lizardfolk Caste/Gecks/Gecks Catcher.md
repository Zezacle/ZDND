---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gecks Catcher
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 14 **Initiative** +2 (12)
> **HP** 30 (12d6 - 12)
> **Speed** 40 ft., climb 40 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 7 | -2 | -2 | 
> | **CON** | 9 | -1 | -1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Gear** Blowgun
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 8
> **Languages** Primordial (Terran)
> **CR** 2 (XP 450; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gecks can hold its breath for an hour.

### Actions
***Multiattack.*** The gecks makes two attacks.

***Cattleprod*.** *Melee Attack Roll:* +4, reach 10 ft. _Hit:_ 7 (1d10 + 2) piercing damage and if the target is a Medium or smaller creature it is [[grappled]] and [[restrained]] (escape DC 12). While grappling a creature in this way, the catcher cannot use its Cattleprod to attack a different target.

***Spit Blowgun.*** *Ranged Attack Roll:* +4, range 25/100 ft. _Hit:_ 3 (1+2) piercing damage plus 5 (2d4) poison damage, and the target is [[poisoned]] until the end of its next turn.

### Bonus Actions
***Shock.*** *Constitution Saving Throw:* DC 12, a creature restrained by the catcher's Cattleprod. *Failure:* The target takes 18 (4d8) lightning damage. *Success:* Half damage only.

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the gecks hits or misses. *Response:* The gecks moves up to its [[speed]] without provoking [[Opportunity Attacks]].