---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gecks Seer
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +6 (16)
> **HP** 88 (16d6 + 32)
> **Speed** 40 ft., climb 40 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **CHA** | 13 | +1 | +1 | 
> | **DEX** | 17 | +3 | +6 | **WIS** | 17 | +3 | +6 | 
> | **CON** | 15 | +2 | +2 | **CHA** | 12 | +1 | +1 | 
> 
> | |
> | - |
> **Gear** Quarterstaff
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 13
> **Languages** Primordial (Terran)
> **CR** 5 (XP 1,800; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gecks can hold its breath for an hour.

### Actions
***Multiattack.*** The gecks makes two Holy Staff attacks.

***Holy Staff.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 60 ft. _Hit:_ 16 (3d8 + 3) radiant damage.

***Spellcasting.*** The gecks casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 14):

**At Will:** [[Detect Magic]], [[Augury]], [[Thaumaturgy]]
**2/Day Each:** [[Moonbeam]] (level 5 version), [[Clairvoyance]]
**1/Day Each:** [[Divination]], [[Cure Wounds]] (level 4 version)

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the gecks hits or misses. *Response:* The gecks moves up to its [[speed]] without provoking [[Opportunity Attacks]].

