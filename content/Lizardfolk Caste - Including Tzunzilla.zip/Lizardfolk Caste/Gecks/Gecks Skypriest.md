---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Gecks Skypriest
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 18 **Initiative** +8 (18)
> **HP** 172 (23d6 + 92)
> **Speed** 40 ft., climb 40 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 11 | +0 | +0 | **INT** | 13 | +1 | +1 |
> | **DEX** | 19 | +4 | +8 | **WIS** | 21 | +5 | +9 | 
> | **CON** | 18 | +4 | +8 | **CHA** | 12 | +1 | +1 | 
> 
> | |
> | - |
> **Gear** Quarterstaff
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 15
> **Languages** Primordial (Terran)
> **CR** 10 (XP 5,900; PB +4)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The gecks can hold its breath for an hour.

***Legendary Resistance (3/Day).*** If the gecks fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

### Actions
***Multiattack.*** The gecks makes three Rod of Many Skies attacks.

***Rod of Many Skies.*** *Melee or Ranged Attack Roll:* +9, reach 5 ft. or range 60 ft. _Hit:_ 23 (4d8 + 5) radiant damage.

***Spellcasting.*** The gecks casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 17):

**At Will:** [[Detect Magic]], [[Augury]], [[Thaumaturgy]]
**2/Day Each:** [[Moonbeam]] (level 5 version), [[Enlarge Reduce]]
**1/Day Each:** [[Call Lightning]], [[Mass Cure Wounds]]

### Bonus Actions
***Master the Skies (Recharge 5-6).*** *Dexterity Saving Throw:* DC 17, creatures of the gecks choice within a 30-foot [[Emanation]] originating from the gecks. *Failure:* The target takes 28 (8d6) lightning damage. *Success:* Half damage only.

***Poison the Unbeliever.*** *Constitution Saving Throw:* DC 17, a creature hit by the gecks's Rod of Many Skies. *Failure:* The target takes 28 (8d6) poison damage and gains [[poisoned]] condition until the end of its next turn. *Success:* Half damage only.

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the gecks hits or misses. *Response:* The gecks moves up to its [[speed]] without provoking [[Opportunity Attacks]].

### Legendary Actions
*Legendary Action Uses: 3. Immediately after another creature’s turn, the gecks can expend a use to take one of the following actions. The gecks regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Foul Earth (1/Round).*** *Dexterity Saving Throw:* DC 17, up to four creatures of the gecks's choice. *Failure:* The target takes 21 (5d6) acid damage and becomes [[Grappled]] (escape DC 17). While Grappled, the target has the Restrained condition. *Success:* Half damage only.

***Retreat.*** The gecks makes one attack and then moves up to its [[Speed]] without provoking [[Opportunity Attacks]]. It cannot end this movement adjacent to a hostile creature.

***Call the Storm.*** The gecks casts [[Call Lightning]], or uses the Magic action to trigger it.

