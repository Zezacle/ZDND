---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Securidon
> *Huge Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +0 (10)
> **HP** 105 (10d10 + 50)
> **Speed** 50 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +4 | **INT** | 2 | -4 | -4 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +4 |
> | **CON** | 21 | +5 | +8 | **CHA** | 9 | -1 | -1 |
> 
> **Skills** Perception +4
> **Senses** Passive Perception 14
> **Languages** None
> **CR** 6 (XP 2,300; PB +3)
>
> | |
> | - |

### Actions
***Multiattack.*** The dinosaur makes two attacks.

***Trample.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 26 (4d10 + 4) bludgeoning damage.

### Bonus Actions
***Brace.*** The dinosaur takes the [[Dodge]] action.

***Displacing Charge (Recharge 5–6).*** The dinosaur moves up to its Speed without provoking [[Opportunity Attacks]] and can move through the spaces of Large or smaller creatures. Each creature whose space the dinosaur enters is targeted once by the following effect. *Dexterity Saving Throw:* DC 15. *Failure:* 15 (2d10 + 4) bludgeoning damage, and the target is pushed 10 feet away from the dinosaur.

### Siege Weapon
*Actions Required to Use: 3. On the dinosaur's turn, [[Gecks Raider]]s on its back can use their action to attack using the Crystal of the Gods.*

***Crystal of the Gods.*** *Dexterity Saving Throw:* DC 15, each creature in a 30-foot-long, 5-foot-wide Line. Failure: 49 (14d6) radiant damage. Success: Half damage.