---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Sprintadon
> *Large Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +2 (12)
> **HP** 34 (4d10 + 12)
> **Speed** 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 18 | +4 | +4 | **INT** | 2 | -4 | -4 |
> | **DEX** | 14 | +2 | +2 | **WIS** | 12 | +1 | +1 |
> | **CON** | 17 | +3 | +3 | **CHA** | 5 | -3 | -3 |
>
> **Skills** Perception +3
> **Senses** Passive Perception 13
> **Languages** None
> **CR** 1 (XP 200; PB +2)
>
> | |
> | - |

### Actions
***Pounce.*** *Melee Attack Roll:* +6 to hit, reach 5 ft. *Hit:* 15 (2d10 + 4) piercing damage and the target is knocked [[prone]].

### Bonus Action
***Sprint.*** The dinosaur moves up to its speed.
