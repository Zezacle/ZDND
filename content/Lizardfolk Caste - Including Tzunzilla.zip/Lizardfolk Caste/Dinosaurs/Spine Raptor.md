---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Spine Raptor
> *Large Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +2 (12)
> **HP** 68 (8d10 + 24)
> **Speed** 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +4 | **INT** | 2 | -4 | -4 |
> | **DEX** | 15 | +2 | +2 | **WIS** | 12 | +1 | +1 |
> | **CON** | 17 | +3 | +3 | **CHA** | 5 | -3 | -3 |
>
> **Skills** Perception +3
> **Senses** Passive Perception 13
> **Languages** None
> **CR** 3 (XP 700; PB +2)
>
> | |
> | - |

### Traits
***Abduct.*** The dinosaur needn’t spend extra movement to move a creature it is grappling.

### Actions
***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 15 (2d10 + 4) piercing damage. If the target is a medium or smaller creature, it is [[Grappled]] (escape DC 14) by the dinosaur.

***Claws.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 8 (1d8 + 4) slashing damage. If the target is a Large or smaller creature and the dinosaur moved 30+ feet straight toward it immediately before the hit, the target has the [[prone]] condition, and the dinosaur can make one Bite attack against it.

### Bonus Actions
***Lockjaw.*** *Strength Saving Throw:* DC 14, one Medium or smaller creature [[Grappled]] by the dinosaur. *Failure:* The target takes 6 (1d6 + 3) piercing damage and becomes [[Restrained]].


