---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Diseradon
> *Huge Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +0 (10)
> **HP** 105 (10d10 + 50)
> **Speed** 50 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +4 | **INT** | 2 | -4 | -4 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +4 |
> | **CON** | 21 | +5 | +8 | **CHA** | 9 | -1 | -1 |
> 
> **Skills** Perception +4
> **Senses** Passive Perception 14
> **Languages** None
> **CR** 6 (XP 2,300; PB +3)
>
> | |
> | - |

### Actions
***Multiattack.*** The dinosaur makes two attacks.

***Gore.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 26 (4d10 + 4) piercing damage. If the dinosaur moved 20+ feet immediately before making this attack, it deals an extra 21 (6d6) bludgeoning damage and knocks the target [[Prone]].

### Siege Weapon
*Actions Required to Use: 3. On the dinosaurs turn, [[Gecks Raider]]s on its back can use their action to attack using Bolt Launcher.*

***Bolt Launcher.*** *Ranged Attack Roll:* +7, range 120 ft. *Hit:* 26 (4d10 + 4) piercing damage.
