---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Pterradyll
> *Medium Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +2 (12)
> **HP** 13 (2d8 + 4)
> **Speed** 10 ft., fly 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 16 | +3 | +3 | **INT** | 2 | -4 | -4 |
> | **DEX** | 14 | +2 | +2 | **WIS** | 12 | +1 | +1 |
> | **CON** | 15 | +2 | +2 | **CHA** | 5 | -3 | -3 |
>
> **Skills** Perception +3
> **Senses** Passive Perception 13
> **Languages** None
> **CR** 1/2 (XP 100; PB +2)
>
> | |
> | - |

### Traits
***Flyby.*** The dinosaur doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach.

### Actions
***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 8 (1d10 + 3) Piercing damage.