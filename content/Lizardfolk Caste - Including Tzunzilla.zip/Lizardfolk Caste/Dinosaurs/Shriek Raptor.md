---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Shriek Raptor
> *Large Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +2 (12)
> **HP** 37 (6d10 + 18)
> **Speed** 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +4 | **INT** | 2 | -4 | -4 |
> | **DEX** | 15 | +2 | +2 | **WIS** | 12 | +1 | +1 |
> | **CON** | 17 | +3 | +3 | **CHA** | 5 | -3 | -3 |
>
> **Skills** Perception +3
> **Senses** Passive Perception 13
> **Languages** None
> **CR** 2 (XP 450; PB +2)
>
> | |
> | - |

### Actions
***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 15 (2d10 + 4) piercing damage.

### Bonus Actions
***Shriek. (Recharge 5-6)*** *Constitution Saving Throw:* DC 13, humanoid creatures within a 15-foot [[Emanation]]. *Failure:* The target takes 6 (1d6 + 3) thunder damage. *Failure by 5 or more:* The target becomes [[Stunned]] until the start of its next turn.


