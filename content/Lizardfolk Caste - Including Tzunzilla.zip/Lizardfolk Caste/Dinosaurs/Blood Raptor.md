---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Blood Raptor
> *Gargantuan Beast (Dinosaur), Unaligned*
>
> | |
> | - |
> **AC** 13 **Initiative** +3 (13)
> **HP** 147 (14d12 + 56)
> **Speed** 50 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 25 | +7 | +10 | **INT** | 2 | -4 | -4 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +4 |
> | **CON** | 19 | +4 | +7 | **CHA** | 9 | -1 | -1 |
>
> **Skills** Perception +4
> **Senses** Passive Perception 14
> **Languages** None
> **CR** 8 (XP 3,900; PB +3)
>
> | |
> | - |

### Actions
***Multiattack.*** The dinosaur makes two attacks. It can replace one attack with Swallow.

***Bite.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:* 33 (4d12 + 7) piercing damage. If the target is a Large or smaller creature, it has the [[Grappled]] condition (escape DC 18). While Grappled, the target has the [[Restrained]] condition and can't be targeted by the tyrannosaurus's Tail.

***Tail.*** *Melee Attack Roll:* +10, reach 15 ft. *Hit:* 25 (4d8 + 7) bludgeoning damage. If the target is a Huge or smaller creature, it's knocked [[prone]].

***Swallow.*** *Strength Saving Throw:* DC 18, one large or smaller creature [[Grappled]] by the dinosaur (it can have up to four creatures swallowed at a time). *Failure:* The target is swallowed by the dinosaur. A swallowed creature is no longer Grappled but instead becomes [[Blinded]] and [[Restrained]], and has Total Cover against attacks and other effects outside the dinosaur. A swallowed creature takes 17 (5d6) Acid damage at the start of each of its turns.

If the dinosaur takes 20 damage or more on a single turn from a creature inside it, the dinosaur must succeed on a DC 17 Constitution saving throw at the end of that turn or regurgitate all swallowed creatures, each of which falls in a space within 10 feet of the dinosaur and lands [[Prone]]. If the dinosaur dies, any swallowed creature no longer has the [[Restrained]] condition and can escape from the corpse using 15 feet of movement, exiting [[Prone]].