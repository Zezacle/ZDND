---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Chamilon Boleador
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 14 **Initiative** +2 (12)
> **HP** 12 (5d6-5)
> **Speed** 30 ft., climb 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 9 | -1 | +1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Skills** Stealth +6
> **Gear** Sling
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 1/2 (XP 100; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The chamilon can hold its breath for an hour.

***Shifting Scales.*** The chamilon makes stealth checks with advantage. While motionless, it treats any rolls of 9 or lower on the [[D20 Test]] as a 10 when making a stealth check.

### Actions
***Bolas.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 20/60 ft.  _Hit:_ 6 (1d8 + 2) bludgeoning damage. The target must make a DC 12 Dexterity saving throw or fall [[prone]].

### Bonus Actions
***Beat the Helpless.*** The chamilon makes an attack against a creature that gained the [[prone]] condition this turn.