---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Chamilon Hunter
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 14 **Initiative** +2 (12)
> **HP** 20 (8d6 - 8)
> **Speed** 30 ft., climb 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 9 | -1 | -1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Skills** Stealth +6
> **Gear** Blowgun
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 1 (XP 200; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The chamilon can hold its breath for an hour.

***Shifting Scales.*** The chamilon makes stealth checks with advantage. While motionless, it treats any rolls of 9 or lower on the [[D20 Test]] as a 10 when making a stealth check.

### Actions
***Ambusher's Blowgun.*** *Ranged Attack Roll:* +4, range 25/100 ft. _Hit:_ 4 (1d4 + 2) piercing damage plus 5 (2d4) poison damage, and the target is [[poisoned]] until the end of its next turn. Targeting a [[prone]] creature with this attack does not impose disadvantage on the attack roll.

### Bonus Actions
***Ambusher.*** When the chamilon hits a a creature with an Ambusher's Blowgun attack, if the chamilon had advantage on the attack roll, it can turn that hit into a critical hit instead.