---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Chamilon Skirmisher
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +2 (12)
> **HP** 45 (10d6 + 10)
> **Speed** 30 ft., climb 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 7 | -2 | -2 | **INT** | 8 | -1 | -1 |
> | **DEX** | 15 | +2 | +4 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 13 | +1 | +1 | **CHA** | 8 | -1 | -1 | 
> 
> | |
> | - |
> **Skills** Stealth +6
> **Gear** Blowgun, Sling
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 3 (XP 700; PB +2)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The chamilon can hold its breath for an hour.

***Shifting Scales.*** The chamilon makes stealth checks with advantage. While motionless, it treats any rolls of 9 or lower on the [[D20 Test]] as a 10 when making a stealth check.

### Actions
***Multiattack.*** The chamilon makes two attacks.

***Bolas.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 20/60 ft.  _Hit:_ 6 (1d8 + 2) bludgeoning damage. The target must make a DC 12 Dexterity saving throw or fall [[prone]].

***Ambusher's Blowgun.*** *Ranged Attack Roll:* +4, range 25/100 ft. _Hit:_ 4 (1d4 + 2) piercing damage plus 5 (2d4) poison damage, and the target is [[poisoned]] until the end of its next turn. Targeting a [[prone]] creature with this attack does not impose disadvantage on the attack roll.

### Bonus Actions
***Beat the Helpless.*** The chamilon makes an attack against a creature that gained the [[prone]] condition this turn.

***Ambusher.*** When the chamilon hits a a creature with an Ambusher's Blowgun attack, if the chamilon had advantage on the attack roll, it can turn that hit into a critical hit instead.

### Reactions
***Skirmisher.*** *Trigger:* An attack made against the chamilon hits or misses. *Response:* The chamilon moves up to its [[speed]] without provoking [[Opportunity Attacks]].