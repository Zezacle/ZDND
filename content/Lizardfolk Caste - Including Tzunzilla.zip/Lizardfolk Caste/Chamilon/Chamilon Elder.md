---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Chamilon Elder
> *Small Elemental, Neutral*
> 
> | |
> | - |
> **AC** 16 **Initiative** +7 (17)
> **HP** 99 (18d6 + 36)
> **Speed** 30 ft., climb 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 12 | +1 | +1 | **INT** | 13 | +1 | +1 |
> | **DEX** | 18 | +4 | +7 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 15 | +2 | +2 | **CHA** | 12 | +1 | +1 |
> 
> | |
> | - |
> **Skills** Stealth +10
> **Gear** Spear
> **Immunities** Poison; Poisoned
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Primordial (Terran)
> **CR** 6 (XP 2,300; PB +3)
> 
> | |
> | - |

### Traits
***Hold Breath.*** The chamilon can hold its breath for an hour.

***Shifting Scales.*** The chamilon makes stealth checks with advantage. While motionless, it treats any rolls of 9 or lower on the [[D20 Test]] as a 10 when making a stealth check.

***Legendary Resistance (2/Day).*** If the chamilon fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%

### Actions
***Multiattack.*** The chamilon makes three attacks.

***Spear.*** *Melee Attack Roll:* +7, reach 5 ft. or range 20/60 ft.  _Hit:_ 8 (1d8 + 4) piercing damage plus 10 (3d6) poison damage, and the target is [[poisoned]] until the end of its next turn.

### Bonus Actions
***Blessed Tip.*** *Constitution Saving Throw:* DC 15, a creature hit by the chamilon's spear. *Failure:* The target takes 18 (4d8) lightning damage. *Success:* Half damage only.

### Legendary Actions
*Legendary Action Uses: 2. Immediately after another creature’s turn, the chamilon can expend a use to take one of the following actions. The chamilon regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%

***Pack Leader (1/Round).*** Up to four creatures of the chamilon's choice can take a reaction to move up to their speed without provoking [[Opportunity Attacks]] and make an attack.

***Retreat.*** The chamilon makes one attack and then moves up to its [[Speed]] without provoking [[Opportunity Attacks]]. It cannot end this movement adjacent to a hostile creature.