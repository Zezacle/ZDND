> [!infobox|left clean wmed static]
> # Sahuagin Sharkwrangler
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 14 **Initiative** +0 (10)
> **HP** 38 (7d8 + 7)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +3 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 11 | +0 | +0 | **WIS** | 16 | +3 | +3 | 
> | **CON** | 12 | +1 | +1 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Javelin (9)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 2 (XP 450; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two attacks, using Lance and Javelin in any combination.

***Lance.*** *Melee Attack Roll*: +5, reach 10 ft. *Hit:* 9 (1d10 + 3) piercing damage.

***Javelin.*** *Melee or Ranged Attack Roll*: +5, reach 5 ft. or range 30/120 ft. *Hit:* 7 (1d6 + 3) piercing damage.

### Bonus Action
***Cavalry.***  The sahuagin orders its mount to move up to its speed and take an action. That action can be the [[Dash]] or [[Disengage]] action, or any action printed on the mount's statblock. If the sahuagin takes this bonus action, the mount does not move or take any actions on its own turn.