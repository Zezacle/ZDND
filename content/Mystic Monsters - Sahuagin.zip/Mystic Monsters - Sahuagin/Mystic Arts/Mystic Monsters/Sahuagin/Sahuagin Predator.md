> [!infobox|left clean wmed static]
> # Sahuagin Predator
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 12 **Initiative** +0 (10)
> **HP** 22 (4d8 + 4)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 13 | +1 | +1 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 10 | +0 | +0 | **WIS** | 13 | +1 | +1 | 
> | **CON** | 12 | +1 | +1 | **CHA** | 9 | -1 | -1 |
>  
> | |
> | - |
> **Skills** Perception +5
> **Resistances** Acid, Cold
> **Gear** Javelin (10)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 1/2 (XP 100; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Javelin attacks.

***Javelin.*** *Melee or Ranged Attack Roll*: +3, reach 5 ft. or range 30/120 ft. *Hit:* 4 (1d6 + 1) piercing damage.

### Bonus Actions
***Aquatic Charge.*** The sahuagin swims up to its Swim Speed straight toward an enemy it can see.