> [!infobox|left clean wmed static]
> # Sahuagin Sacrosanct
> *Large Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 17 **Initiative** +13 (23)
> **HP** 276 (24d10 + 144)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 20 | +5 | +10 | **INT** | 15 | +2 | +2 | 
> | **DEX** | 17 | +3 | +3 | **WIS** | 20 | +5 | +10 | 
> | **CON** | 23 | +6 | +10 | **CHA** | 17 | +3 | +3 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Breastplate, Trident
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 13 (XP 10,000; PB +5)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Legendary Resistance (3/Day).*** If the sahuagin fails a saving throw, it can choose to succeed instead.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Magic Resistance.*** The sahuagin has Advantage on saving throws against spells and other magical effects.

***Regeneration.*** The sahuagin regains 10 Hit Points at the start of each of its turns if it has at least 1 Hit Point.

***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes four Toothed Trident attacks.

***Toothed Trident.*** *Melee Attack Roll*: +9, reach 5 ft. *Hit:* 14 (2d8 + 5) piercing damage and 13 (2d12) force damage, and the target has disadvantage on its next attack roll before the start of the sahuagin's next turn.

***Spew Blood (Recharge 5–6).*** *Dexterity Saving Throw:* DC 18, each creature in a 60-foot-long, 5-foot-wide [[Line]]. *Failure:* 54 (12d8) Acid damage. *Success:* Half damage.

### Bonus Actions
**Bloodthirsty Bite.** *Melee Attack Roll*: +9, reach 5 ft. *Hit:* 23 (4d8 + 5) piercing damage and 18 (4d8) acid damage, and the target is [[Grappled]] and [[Restrained]] by the sahuagin (escape DC 18).

### Legendary Actions
*Legendary Action Uses: 3. Immediately after another creature’s turn, the sahuagin can expend a use to take one of the following actions. The sahuagin regains all expended uses at the start of each of its turns.*
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%

***Drown (1/Round).*** *Constitution Saving Throw:* DC 18, one creature the sahuagin can see within 5 feet. *Failure:* The target is [[Curses|cursed]], and begins [[Suffocation|suffocating]] for the next minute. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success. The target stops drowning if the Sacrosanct is [[Incapacitated]] or killed.

***Fierce Strikes.*** The sahuagin makes a Toothed Trident attack with [[Advantage]].

***Unrelenting Swimmer.*** The sahuagin swims up to its Swim Speed straight toward an enemy it can see without provoking [[Opportunity Attacks]].