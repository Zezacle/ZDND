> [!infobox|left clean wmed static]
> # Sahuagin Warchief
> *Large Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 17 **Initiative** +6 (16)
> **HP** 195 (17d10 + 102)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 20 | +5 | +9 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 15 | +2 | +2 | **WIS** | 16 | +3 | +7 | 
> | **CON** | 23 | +6 | +10 | **CHA** | 17 | +3 | +3 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Breastplate, Trident
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 9 (XP 5,000; PB +4)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes four Toothed Trident attacks.

***Toothed Trident.*** *Melee Attack Roll*: +9, reach 5 ft. *Hit:* 14 (2d8 + 5) piercing damage and 13 (2d12) force damage, and the target has disadvantage on its next attack roll before the start of the sahuagin's next turn.

***Acidic Blast.*** *Melee or Ranged Attack Roll*: +5, reach 5 ft. or range 120 ft. *Hit:* 10 (2d6 + 3) acid damage.

### Bonus Actions
**Bloody Strikes.** When the sahuagin hits with an attack while its [[Bloodied]], it deals an additional 16 (3d10) acid damage.

### Reaction
***Bleed Acid.*** *Trigger:* The sahuagin takes damage: *Response—Constitution Saving Throw:* DC 15, [[Creature|Creatures]] of the sahuagin's choice in a 5-foot [[Emanation]] originating from the sahuagin. *Failure:* 17 (5d6) acid damage, and the target cannot regain hit points until the end of the sahuagin's next turn. *Success:* Half damage only.