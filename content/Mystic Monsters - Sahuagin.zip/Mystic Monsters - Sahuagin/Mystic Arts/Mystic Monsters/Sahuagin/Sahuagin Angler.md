> [!infobox|left clean wmed static]
> # Sahuagin Angler
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 14 **Initiative** +0 (10)
> **HP** 67 (9d8 + 27)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +3 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 11 | +0 | +0 | **WIS** | 13 | +1 | +1 | 
> | **CON** | 16 | +3 | +3 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Skills** Perception +6
> **Resistances** Acid, Cold
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 3 (XP 700; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Unhinged Jaw attacks.

***Unhinged Jaw.*** *Melee Attack Roll*: +5, reach 5 ft. *Hit:* 10 (2d6 + 3) piercing damage and 5 (2d4) acid damage. 

### Bonus Actions
***Light Lure.*** *Wisdom Saving Throw:* DC 11, each creature in a 30-foot Emanation originating from the sahuagin. *Failure:* The target becomes the [[Charmed]] until the start of the sahuagin's next turn. If the target failed by 5 or more it is also [[Incapacitated]] while charmed in this way.