### Sahuagin Tribe
[[Sahuagin]], or "Sea Devils" are predatorial hunters from beneath the waves. They'll ransack ships, fishing villages, and undersea communities, not just to sate their unending thirst for blood, but to claim treasure and to make blood sacrifices to their fiendish diety; the Great Shark.

While, thankfully, these Sahuagin are typically content in raiding. There are rare occasions where their lands are threatened, their territory violated, or their god demands grander sacrifices, where the entire tribe is brought to bear against the folks of the land or the sea. In those times, woe betide anyone who stands in the way of a Sahuagin Tribe on the war path.

- [[Sahuagin Minnow]] (CR 1/8)
- [[Sahuagin Predator]] (CR 1/2)
- [[Sahuagin Harpooner]] (CR 1)
- [[Sahuagin Shaman]] (CR 2)
- [[Sahuagin Sharkwrangler]] (CR 2)
- [[Sahuagin Angler]] (CR 3)
- [[Sahuagin Bloodletter]] (CR 4)
- [[Sahuagin Toothmage]] (CR 6)
- [[Sahuagin Warchief]] (CR 9)
- [[Sahuagin Sacrosanct]] (CR 13)

Sahuagin can all telepathically speak to, and command, sharks. Use the following statblocks to supplement Sahuagin encounters:

- [[Reef Shark]]
- [[Hunter Shark]]
- [[Giant Shark]]