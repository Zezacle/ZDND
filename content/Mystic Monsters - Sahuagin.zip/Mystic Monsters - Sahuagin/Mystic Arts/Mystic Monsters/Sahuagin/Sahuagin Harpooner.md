> [!infobox|left clean wmed static]
> # Sahuagin Harpooner
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 12 **Initiative** +0 (10)
> **HP** 38 (7d8 + 7)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 13 | +1 | +1 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 10 | +0 | +0 | **WIS** | 13 | +1 | +1 | 
> | **CON** | 12 | +1 | +1 | **CHA** | 9 | -1 | -1 |
>  
> | |
> | - |
> **Skills** Perception +5
> **Resistances** Acid, Cold
> **Gear** Javelin (10)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 1 (XP 200; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Harpoon attacks.

***Harpoon.*** *Melee or Ranged Attack Roll*: +3, reach 5 ft. or range 30/120 ft. *Hit:* 4 (1d6 + 1) piercing damage. If the target is a medium or smaller [[creature]], it's [[Grappled]] (escape DC 11) a rope connects the target back to the sahuagin. 

The rope can be damaged, freeing a creature it has Grappled when destroyed (AC 20, HP 10, Immunity to Poison and Psychic damage).

***Claws.*** *Melee or Ranged Attack Roll*: +3, reach 5 ft. *Hit:* 4 (1d6 + 1) piercing damage.

### Bonus Actions
***Reel.*** The sahuagin pulls each creature [[Grappled]] by it up to 30 feet straight toward it.