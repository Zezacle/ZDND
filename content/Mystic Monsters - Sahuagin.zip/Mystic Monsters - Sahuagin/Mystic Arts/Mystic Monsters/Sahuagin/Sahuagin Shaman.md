> [!infobox|left clean wmed static]
> # Sahuagin Shaman
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 12 **Initiative** +0 (10)
> **HP** 38 (7d8 + 7)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 13 | +1 | +1 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 11 | +0 | +0 | **WIS** | 16 | +3 | +3 | 
> | **CON** | 12 | +1 | +1 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Javelin (9)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin
> **CR** 2 (XP 450; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Acidic Blast attacks.

***Acidic Blast.*** *Melee or Ranged Attack Roll*: +5, reach 5 ft. or range 120 ft. *Hit:* 10 (2d6 + 3) acid damage.

***Spellcasting.*** The sahuagin casts one of the following spells, requiring no Material components and using Wisdom as the spellcasting ability (spell save DC 13):

**At Will:** [[Thaumaturgy]], [[Entangle]]
**2/Day Each:** [[Comprehend Languages]], [[Confusion]], [[Hold Person]]

### Bonus Actions
***Blessing of the Sea (2/Day).*** The sahuagin casts [[Mass Healing Word]], using the same spellcasting ability as Spellcasting.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%