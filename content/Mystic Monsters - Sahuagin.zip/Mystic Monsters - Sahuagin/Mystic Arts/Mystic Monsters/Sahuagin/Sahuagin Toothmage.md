> [!infobox|left clean wmed static]
> # Sahuagin Toothmage
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 14 **Initiative** +0 (10)
> **HP** 127 (15d8 + 60)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +6 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 11 | +0 | +0 | **WIS** | 18 | +4 | +7 | 
> | **CON** | 19 | +4 | +4 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Spear (3)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 6 (XP 2,300; PB +3)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Toothed Spear attacks.

***Toothed Spear.*** *Melee or Ranged Attack Roll*: +7, reach 5 ft. or range 20/60 ft. *Hit:* 10 (2d6 + 4) piercing damage and 13 (2d12) force damage.

**At Will:** [[Thaumaturgy]], [[Entangle]]
**2/Day Each:** [[Comprehend Languages]], [[Confusion]], [[Hold Person]]
**1/Day Each:** [[Banishment]], [[Blight]], [[Control Weather]]

### Bonus Actions
***Teeth of Great Shark.*** [[Ally|Allied]] [[Creature|Creatures]] in a 60-foot [[Emanation]] originating from the sahuagin deal an additional 13 (2d12) force damage until the end of the sahuagin's next turn.

***Blessing of the Sea (2/Day).*** The sahuagin casts [[Mass Healing Word]], using the same spellcasting ability as Spellcasting.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%

### Reactions
***Protective Magic (3/Day).*** The sahuagin casts [[Counterspell]] or [[Shield]] in response to the spell’s trigger, using the same spellcasting ability as Spellcasting.
> [!checks|no-title]
> -
> 	- **Used**
> 	- [ ] %% %%
> 	- [ ] %% %%
> 	- [ ] %% %%