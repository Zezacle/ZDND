> [!infobox|left clean wmed static]
> # Sahuagin Bloodletter
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 14 **Initiative** +0 (10)
> **HP** 100 (13d8 + 39)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +5 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 11 | +0 | +0 | **WIS** | 16 | +3 | +5 | 
> | **CON** | 16 | +3 | +3 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Skills** Perception +7
> **Resistances** Acid, Cold
> **Gear** Spear (3)
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 4 (XP 1,100; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Multiattack.*** The sahuagin makes two Toothed Spear attacks.

***Toothed Spear.*** *Melee or Ranged Attack Roll*: +5, reach 5 ft. or range 20/60 ft. *Hit:* 10 (2d6 + 3) piercing damage and 13 (2d12) force damage.

### Bonus Actions
***Whirlpool of Teeth. (Recharge 5-6).*** *Dexterity Saving Throw:* DC 13, each creature in a 30-foot [[Emanation]] originating from the sahuagin. *Failure:* 13 (2d12) force damage, and the target cannot regain [[Hit Points]] until the end of their next turn. *Success:* Half damage only.