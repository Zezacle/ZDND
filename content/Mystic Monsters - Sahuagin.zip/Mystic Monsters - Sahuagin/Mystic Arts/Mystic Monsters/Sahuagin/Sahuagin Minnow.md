> [!infobox|left clean wmed static]
> # Sahuagin Minnow
> *Medium Fiend, Lawful Evil*
> 
> | |
> | - |
> **AC** 12 **Initiative** +0 (10)
> **HP** 9 (2d8)
> **Speed** 30 ft., swim 40 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 13 | +1 | +1 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 10 | +0 | +0 | **WIS** | 13 | +1 | +1 | 
> | **CON** | 10 | +0 | +0 | **CHA** | 9 | -1 | -1 |
>  
> | |
> | - |
> **Skills** Perception +5
> **Resistances** Acid, Cold
> **Senses** Blindsight 10 ft., Darkvision 120 ft., Passive Perception 15
> **Languages** Sahuagin, Telepathy 120 ft. (sharks only)
> **CR** 1/8 (XP 25; PB +2)
> 
> | |
> | - |
> **Habitat** Coastal, Underwater
> **Treasure** Any

### Traits
***Blood Frenzy.*** The sahuagin has [[Advantage]] on attack rolls against any [[creature]] that doesn’t have all its [[Hit Points]].

***Limited Amphibiousness.*** The sahuagin can breathe air and water, but it must be submerged at least once every 4 hours to avoid [[suffocation|suffocating]] outside water.

### Actions
***Claw.*** *Melee Attack Roll:* +3, reach 5 ft. _Hit:_ 4 (1d6 + 1) Slashing damage.