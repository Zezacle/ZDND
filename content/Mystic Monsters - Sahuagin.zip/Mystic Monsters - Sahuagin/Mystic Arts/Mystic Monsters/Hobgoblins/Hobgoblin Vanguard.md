> [!infobox|left clean wmed static]
> # Hobgoblin Vanguard
> *Medium Fey, Lawful Evil*
> 
> | |
> | - |
> **AC** 20 **Initiative** +4 (14)
> **HP** 67 (9d8 + 27)
> **Speed** 30 ft.
> 
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 16 | +3 | +3 | **INT** | 12 | +1 | +1 | 
> | **DEX** | 14 | +2 | +2 | **WIS** | 10 | +0 | +0 | 
> | **CON** | 17 | +3 | +3 | **CHA** | 13 | +1 | +1 |
>  
> | |
> | - |
> **Gear** Plate Armor, Javelin (9), Warhammer, Shield
> **Senses** Darkvision 60 ft., Passive Perception 10
> **Languages** Common, Goblin.
> **CR** 4 (XP 1,100; PB +2)
> 
> | |
> | - |
> **Habitat** Desert, Forest, Grassland, Hill, Mountain, Planar (Acheron), Underdark
> **Treasure** Armaments, Individual

### Traits
***Regimented.*** The hobgoblin deals an extra 7 (2d6) damage to a creature it hits with an attack while the hobgoblin is within 5 feet of an [[Ally|Allied]] [[Creature]] that isn't [[Incapacitated]].

### Actions
***Multiattack.*** The hobgoblin makes two attacks, using Warhammer or Javelin in any combination.

***Warhammer.*** *Melee Attack Roll*: +6, reach 5 ft. *Hit:* 7 (1d8 + 3) slashing damage, and the target can be pushed 10 feet straight away from the hobgoblin.

***Javelin.*** *Melee or Ranged Attack Roll*: +6, reach 5 ft. or range 30/120 ft. _Hit:_ 11 (2d6 + 4) piercing damage.

### Bonus Actions
***Standard Bearer (Recharge 5-6).*** [[Ally|Allied]] [[Creature|Creatures]] in a 30-foot [[Emanation]] can use their reaction to move up to half their [[Speed]] without provoking [[Opportunity Attacks]]. They must end this movement closer to the hobgoblin than they started it.