---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Child
>
> *Medium or Small Undead, Neutral Evil*
>
> | |
> | - |
>
> **AC** 16
> **Initiative** +3 (13)
> **HP** 7 (1d8 + 3)
> **Speed** 30 ft. [[Flying|Fly]] 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 11 | +0 | +0 |
> | **DEX** | 16 | +3 | +6 | **WIS** | 10 | +0 | +3 |
> | **CON** | 16 | +3 | +3 | **CHA** | 12 | +1 | +1 |
>
> **Skills** [[Perception]] +3, [[Stealth]] +6
> **Vulnerabilities** Radiant
> **Resistances** Bludgeoning, Piercing, Slashing
> **Immunities** Necrotic, Poison
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 13
> **Languages** Common plus one other language
> **CR** 1 (XP 200; PB +2)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Dark Immunities.*** While not in sunlight, the vampire has immunity to bludgeoning, piercing, and slashing damage.

### Actions

***Multiattack.*** The vampire makes two Claw attacks.

***Claw.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 10 (2d4 + 5) Slashing damage. If the target is a Medium or smaller creature, it's [[Grappled]] (escape DC 12) from one of two claws.

### Bonus Actions
***Deathless Agility.*** The vampire takes the [[Dash]] or [[Disengage]] action.