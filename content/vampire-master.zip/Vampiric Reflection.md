---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampiric Reflection
>
> *Medium or Small Undead, Lawful Evil*
>
> | |
> | - |
>
> **AC** 18
> **Initiative** +14 (24)
> **HP** 10 (1d8 + 6)
> **Speed** 40 ft., [[Climbing|Climb]] 40 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 17 | +3 | +3 |
> | **DEX** | 18 | +4 | +9 | **WIS** | 15 | +2 | +7 |
> | **CON** | 23 | +6 | +11 | **CHA** | 18 | +4 | +9 |
>
> **Skills** [[Perception]] +7, [[Stealth]] +9
> **Immunities** Bludgeoning, Piercing, Slashing, Necrotic, Poison
> **Senses** [[Darkvision]] 120 ft.; [[Passive Perception]] 17
> **Languages** Common plus two other languages
> **CR** 14 (XP 11,500, or 13,000 in lair; PB +5)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |


### Traits

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Forbiddance.*** The vampire can't enter a residence without an invitation from an occupant.

***False Appearance.*** Unless it is in sunlight, the vampiric reflection is indistinguishable from the vampire that created it.

### Actions

***Multiattack.*** The vampire makes two Grave Strike attacks.

***Grave Strike.*** *Melee Attack Roll:* +10, reach 5 ft. *Hit:* 9 (1d8 + 5) Bludgeoning damage plus 10 (3d6) Necrotic damage. If the target is a Large or smaller creature, it has the [[Grappled]] condition (escape DC 18) from one of two hands.

### Bonus Actions

**_Deathless Agility._** The vampire takes the [[Dash]] or [[Disengage]] action.
