---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Weretiger
>
> *Medium or Small Monstrosity (Lycanthrope), Neutral*
>
> | |
> | - |
>
> **AC** 12
> **Initiative** +2 (12)
> **HP** 120 (16d8 + 48)
> **Speed** 30 ft., 40 ft. (tiger form only)
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +3 | **INT** | 10 | +0 | +0 |
> | **DEX** | 15 | +2 | +2 | **WIS** | 13 | +1 | +1 |
> | **CON** | 16 | +3 | +3 | **CHA** | 11 | +0 | +0 |
>
> **Skills** [[Perception]] +5, [[Stealth]] +4
> **Gear** Longbow
> **Immunities** Bludgeoning, Piercing, Slashing
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 15
> **Languages** Common (can't speak in tiger form)
> **CR** 4 (XP 1,100; PB +2)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Running Leap.*** With a 10-foot running start, the weretiger can Long Jump up to 25 feet.

***Lycanthropic Distress.*** If the lycanthrope's true form is reduced to 0 Hit Points it instead becomes a **weretiger**.

### Actions

***Multiattack.*** The weretiger makes two Scratch attacks. It can replace one attack with a Bite attack.

***Bite*** *Melee Attack Roll:*  +5, reach 5 ft. *Hit:* 12 (2d8 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. *Constitution Saving Throw:* DC 13. *Failure:* The target is cursed. If the cursed target drops to 0 Hit Points, it instead becomes a **Weretiger** under the GM's control and has 10 Hit Points. *Success:* The target is immune to this weretiger's curse for 24 hours.

***Scratch.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage.

### Bonus Actions

***Prowl.*** The weretiger moves up to its [[Speed]] without provoking [[Opportunity Attacks]]. At the end of this movement, the weretiger can take the Hide action.

***Shape-Shift.*** The weretiger shape-shifts into a [[Tiger]], or [[Saber-Toothed Tiger]] or it's true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn't transformed.


