---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Wereboar
>
> *Medium or Small Monstrosity (Lycanthrope), Neutral Evil*
>
> | |
> | - |
>
> **AC** 15
> **Initiative** +2 (12)
> **HP** 97 (15d8 + 30)
> **Speed** 30 ft., 40 ft. (boar form only)
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 17 | +3 | +3 | **INT** | 10 | +0 | +0 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 11 | +0 | +0 |
> | **CON** | 15 | +2 | +2 | **CHA** | 8 | -1 | -1 |
>
> **Skills** [[Perception]] +2
> **Gear** Javelins (6)
> **Immunities** Bludgeoning, Piercing, Slashing
> **Senses** [[Passive Perception]] 12
> **Languages** Common (can't speak in boar form)
> **CR** 4 (XP 1,100; PB +2)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Bloodied Fury.*** The wereboar has Advantage on melee attack rolls while it is [[Bloodied]].

***Lycanthropic Distress.*** If the lycanthrope's true form is reduced to 0 Hit Points it instead becomes a **Wereboar**.

### Actions

***Multiattack.*** The wereboar makes two Gore attacks. It can replace one attack with a Bite attack.

***Bite.*** *Melee Attack Roll:*  +5, reach 5 ft. *Hit:* 12 (2d8 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. *Constitution Saving Throw:* DC 12. *Failure:* The target is cursed. At the next full moon, the cursed target becomes a **Werebear** under the GM's control. *Success:* The target is immune to this werebear's curse for 24 hours.

***Gore.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Piercing damage. If the target is a Medium or smaller creature and the wereboar moved 20+ feet straight toward it immediately before the hit, the target takes an extra 7 (2d6) Piercing damage and has the [[Prone]] condition.

### Bonus Actions

***Shape-Shift.*** The wereboar shape-shifts into a [[Boar]], or [[Giant Boar]], or it's true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn't transformed.
