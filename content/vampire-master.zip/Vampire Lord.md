---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Lord
>
> *Medium or Small Undead, Lawful Evil*
>
> | |
> | - |
>
> **AC** 22
> **Initiative** +21 (31)
> **HP** 405 (30d8 + 270)
> **Speed** 60 ft., [[Climbing|Climb]] 60 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 23 | +5 | +13 | **INT** | 19 | +4 | +4 |
> | **DEX** | 23 | +5 | +13 | **WIS** | 18 | +4 | +12 |
> | **CON** | 29 | +9 | +17 | **CHA** | 24 | +6 | +14 |
>
> **Skills** [[Deception]] +14, [[Insight]] +12, [[Perception]] +12, [[Stealth]] +13
> **Immunities** Bludgeoning, Piercing, Slashing, Necrotic, Poison
> **Senses** [[Darkvision]] 120 ft.; [[Passive Perception]] 17
> **Languages** Common plus two other languages
> **CR** 26 (XP 75,000, or 90,000 in lair; PB +8)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |


### Traits

***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the vampire fails a saving throw, it can choose to succeed instead.

> [!checks|no-title]
> -
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%

***Mythic Beast. (1/Day)*** If the Vampire Lord would be reduced to 0 hit points, its current hit point total instead resets to 405 hit points, it recharges its Orb of Insanity, and it regains any expended uses of Legendary Resistance. Additionally, the vampire can now use the options in the "Mythic Actions" section for 1 hour.

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Dark Regeneration.*** The vampire regains 50 hit points at the start of its turn if it has at least 1 hit point. If the vampire is in sunlight or running water, this trait doesn’t function at the start of the vampire’s next turn.

### Actions

***Multiattack.*** The vampire makes three Grave Strike attacks and uses Forceful Bite. It can replace a Grave Strike to use Innate Spellcasting.

***Grave Strike.*** *Melee Attack Roll:* +13, reach 5 ft. *Hit:* 14 (2d8 + 5) Bludgeoning damage plus 18 (5d6) Necrotic damage. If the target is a Large or smaller creature, it has the [[Grappled]] condition (escape DC 18) from one of two hands.

***Forceful Bite.*** *Constitution Saving Throw:* DC 22, one creature within 5 feet. *Failure:* 15 (4d4 + 5) Piercing damage plus 55 (10d10) Necrotic damage. The target's Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount. A Humanoid reduced to 0 Hit Points is killed. If the Humanoid is then buried, it rises the following sunset as a **Vampire Spawn** under the vampire's control.

***Innate Spellcasting.*** The vampire casts one of the following spells requiring no components, using Charisma as the spellcasting ability (spell save DC 22):

**At will:** [[Command]], [[Detect Thoughts]], [[04) Backlink Glossary/Spells/Level 2/Darkness|Darkness]], [[Sleep]].
**2/day each:** [[Blight]], [[Fly]], [[Greater Invisibility]], [[Insect Plague]], [[Polymorph]]
**1/day each:** [[Animate Objects]], [[Project Image]], [[Control Weather]], [[Scrying]], [[Teleport]]

### Bonus Actions

***Orb of Insanity (Recharge 6).*** *Wisdom Saving Throw:* DC 22, each creature in a 20-foot-radius Sphere centered on a point the vampire can see within 120 feet. *Failure:* 35 (10d6) Psychic damage plus 35 (10d6) Necrotic damage and the target is [[Frightened]] of the vampire. *Success:* Half damage.

***Shape-Shift.*** If the vampire isn’t in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.), or it returns to its vampire form. Anything it is wearing transforms with it. While in bat form, the vampire can’t speak. Its game statistics, other than its size and Speed, are unchanged.

***Shadow Step.*** The Vampire teleports to an unoccupied space within 30 feet it can see.

### Reactions
***Protective Magic (3/Day).*** The vampire lord casts [[Counterspell]] or [[Shield]] in response to the spell's trigger, using the same spellcasting ability as Innate Spellcasting.

### Legendary Actions
*Legendary Action Uses: 4 (5 in Lair). Immediately after another creature's turn, the vampire can expend a use to take one of the following actions. The vampire regains all expended uses at the start of each of its turns.*

> [!checks|no-title]
> -
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%

***Beguile. (1/Round)*** The vampire casts *[[Dominate Monster]]*, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 22).

***Drain Magic. (1/Round)*** The vampire casts *[[Dispel Magic]]*, requiring no spell components and using Charisma as the spellcasting ability.

***Deathless Strike.*** The vampire moves up to its Speed without provoking [[opportunity attacks]], and it makes one Grave Strike attack.

### Mythic Actions
If the Mythic Beast trait has activated in the last hour, the vampire lord can use the options below as legendary actions.

***Cast a Spell (1/Round).*** The Vampire Lord casts a spell from its innate spellcasting trait.

***Unleash the Children (1/Round.)*** The Vampire Lord summons 7 (2d6) [[Vampire Child]]ren that roll initiative and follow the vampire lord's every command.