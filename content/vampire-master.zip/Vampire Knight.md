---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Knight
>
> *Medium or Small Undead, Neutral Evil*
>
> | |
> | - |
>
> **AC** 20
> **Initiative** +3 (13)
> **HP** 161 (19d8 + 76)
> **Speed** 30 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 11 | +0 | +0 |
> | **DEX** | 16 | +3 | +7 | **WIS** | 10 | +0 | +4 |
> | **CON** | 18 | +4 | +4 | **CHA** | 16 | +3 | +3 |
>
> **Skills** [[Perception]] +3, [[Stealth]] +6
> **Immunities** Bludgeoning, Piercing, Slashing, Necrotic, Poison
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 13
> **Languages** Common plus one other language
> **CR** 9 (XP 1,800; PB +4)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Misty Escape.*** If the vampire is reduced to 0 Hit Points outside its resting place, it uses Shape-Shifts to become a [[Vampiric Mist]] (no action required). If it can't use Shape-Shift, it is destroyed.

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Unholy Regeneration.*** The vampire regains 20 hit points at the start of its turn if it has at least 1 hit point. If the vampire takes radiant damage this trait doesn’t function at the start of the vampire’s next turn.

***Vampire Weakness.*** The vampire has these weaknesses:

- **Forbiddance.** The vampire can't enter a residence without an invitation from an occupant.
- **Stake to the Heart.** If a wooden stake is driven into the vampire's heart while the vampire is [[Paralyzed]] and at 0 Hit Points, it is destroyed.

### Actions

***Multiattack.*** The vampire makes three Blood Sword attacks. It can replace one attack to use Innate Spellcasting.

***Blood Sword.*** *Melee Attack Roll:* +9, reach 5 ft. *Hit:* 14 (2d8 + 5) Slashing damage and 10 (3d6) Necrotic damage. The target's Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount.

***Innate Spellcasting.*** The vampire casts one of the following spells requiring no components, using Charisma as the spellcasting ability (spell save DC 16):

**At will:** [[Command]], [[04) Backlink Glossary/Spells/Level 2/Darkness|Darkness]]
**2/day each:** [[Blight]], [[Dispel Magic]], [[Hold Person]]

### Bonus Actions
***Deathless Agility.*** The vampire takes the [[Dash]] or [[Disengage]] action.

***Shape-Shift.*** If the vampire isn’t in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.), or it returns to its vampire form. Anything it is wearing transforms with it. While in bat form, the vampire can’t speak. Its game statistics, other than its size and Speed, are unchanged.

### Reaction
***Parry.*** *Trigger:* The vampire knight is hit by a melee attack roll while holding a weapon. *Response:* The vampire knight adds 4 to its AC against that attack, possibly causing it to miss.

