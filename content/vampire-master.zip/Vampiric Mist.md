---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampiric Mist
>
> *Tiny Undead, Lawful Evil*
>
> | |
> | - |
>
> **AC** 18
> **Initiative** +14 (24)
> **HP** 1
> **Speed** 5 ft., [[Flying|Fly]] 300 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 17 | +3 | +3 |
> | **DEX** | 18 | +4 | +9 | **WIS** | 15 | +2 | +7 |
> | **CON** | 23 | +6 | +11 | **CHA** | 18 | +4 | +9 |
> 
> **Immunities** All damage
> **Senses** [[Blindsight]] 60 ft.; [[Passive Perception]] 11
> **Languages** None
> **CR** 0 (XP 10; PB +2)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits
***Without Form.*** Vampiric Mist cannot take any actions or interact with objects. It is weightless and can enter an enemy's space and stop there. If air can pass through a space, the mist can do so, but it can't pass through liquid.

***Homeward Bound.*** The Vampiric Mist knows the shortest route to its resting place.

***Burning Sunlight.*** If the Vampiric Mist starts its turn in sunlight it is destroyed.

***Race Against Doom.*** If the Vampiric Mist doesn't return to its resting place within 2 hours*, it's destroyed. Once in its resting place, it shape-shifts back into its original form and is [[paralyzed]] until it regains any [[Hit Points]], and it regains 1 Hit Point after spending 1 hour there.

* 3 hours at 300 ft. per round means it can travel 68 miles, or just shy of 3 hexes.