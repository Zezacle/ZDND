---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Wererat
>
> *Medium or Small Monstrosity (Lycanthrope), Lawful Evil*
>
> | |
> | - |
>
> **AC** 13
> **Initiative** +3 (13)
> **HP** 60 (11d8 + 11)
> **Speed** 30 ft., [[Climbing|Climb]] 30 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 10 | +0 | +0 | **INT** | 11 | +0 | +0 |
> | **DEX** | 16 | +3 | +3 | **WIS** | 10 | +0 | +0 |
> | **CON** | 12 | +1 | +1 | **CHA** | 8 | -1 | -1 |
>
> **Skills** [[Perception]] +4, [[Stealth]] +5
> **Gear** Hand Crossbow
> **Immunities** Bludgeoning, Piercing, Slashing
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 14
> **Languages** Common (can't speak in rat form)
> **CR** 2 (XP 450; PB +2)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Pack Tactics.*** The werewolf has Advantage on an attack roll against a creature if at least one of the werewolf's allies is within 5 feet of the creature and the ally isn't [[Incapacitated]].

***Agile.*** The rat doesn't provoke an [[Opportunity Attack]] when it moves out of an enemy's reach.

***Lycanthropic Distress.*** If the lycanthrope's true form is reduced to 0 Hit Points it instead becomes a **Wererat**.

### Actions

***Multiattack.*** The wererat makes two Scratch attacks. It can replace one attack with a Bite attack.

***Bite*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 8 (2d4 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. *Constitution Saving Throw:* DC 11. *Failure:* The target is cursed. If the cursed target drops to 0 Hit Points, it instead becomes a **Wererat** under the GM's control and has 10 Hit Points. *Success:* The target is immune to this wererat's curse for 24 hours.

***Scratch.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 6 (1d6 + 3) Slashing damage.

### Bonus Actions

***Shape-Shift.*** The wererat shape-shifts into a [[Rat]], or [[Giant Rat]], or it's true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn't transformed.
