---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Werebear
>
> *Medium or Small Monstrosity (Lycanthrope), Neutral Good*
>
> | |
> | - |
>
> **AC** 15
> **Initiative** +3 (13)
> **HP** 135 (18d8 + 54)
> **Speed** 30 ft., 40 ft. (bear form only), [[Climbing|Climb]] 30 ft. (bear form only)
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 19 | +4 | +4 | **INT** | 11 | +0 | +0 |
> | **DEX** | 10 | +0 | +0 | **WIS** | 12 | +1 | +1 |
> | **CON** | 17 | +3 | +3 | **CHA** | 12 | +1 | +1 |
>
> **Skills** [[Perception]] +7
> **Gear** Handaxes (4)
> **Immunities** Bludgeoning, Piercing, Slashing
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 17
> **Languages** Common (can't speak in bear form)
> **CR** 5 (XP 1,800; PB +3)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Lycanthropic Distress.*** If the lycanthrope's true form is reduced to 0 Hit Points it instead becomes a **Werebear**.

### Actions

***Multiattack.*** The werebear makes two Claw attacks. It can replace one attack with a Bite attack.

***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 17 (2d12 + 4) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. *Constitution Saving Throw:* DC 14. *Failure:* The target is cursed. At the next full moon, the cursed target becomes a **Werebear** under the GM's control. *Success:* The target is immune to this werebear's curse for 24 hours.

***Claw.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 14 (3d6 + 4) slashing damage. If the target is a Large or smaller creature, it's knocked [[Prone]].

### Bonus Actions

***Shape-Shift.*** The wereboar shape-shifts into a [[Brown Bear]], or it's true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn't transformed.
