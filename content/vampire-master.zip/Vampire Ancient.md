---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Ancient
>
> *Medium or Small Undead, Neutral Evil*
>
> | |
> | - |
>
> **AC** 18
> **Initiative** +3 (13)
> **HP** 161 (19d8 + 76)
> **Speed** 30 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 11 | +0 | +0 |
> | **DEX** | 16 | +3 | +7 | **WIS** | 10 | +0 | +4 |
> | **CON** | 18 | +4 | +8 | **CHA** | 18 | +4 | +4 |
>
> **Skills** [[Perception]] +3, [[Stealth]] +6
> **Immunities** Bludgeoning, Piercing, Slashing, Necrotic, Poison
> **Senses** [[Darkvision]] 60 ft. [[Blindsight]] 60 ft.; [[Passive Perception]] 13
> **Languages** Common plus one other language
> **CR** 12 (XP 8,400; PB +4)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |
> ![[Infobox Blank Space.png]]
> ![[Infobox Blank Space.png]]

### Traits

***Legendary Resistance (2/Day).*** If the vampire fails a saving throw, it can choose to succeed instead.

> [!checks|no-title]
> -
>  - [ ] %% %%
>  - [ ] %% %%

***Misty Escape.*** If the vampire is reduced to 0 Hit Points outside its resting place, it uses Shape-Shifts to become a [[Vampiric Mist]] (no action required). If it can't use Shape-Shift, it is destroyed.

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Silent Stalker.*** While in [[Dim Light]] or [[04) Backlink Glossary/Rules/Darkness|Darkness]], the vampire is [[invisible]].

***Unholy Regeneration.*** The vampire regains 20 hit points at the start of its turn if it has at least 1 hit point. If the vampire takes radiant damage this trait doesn’t function at the start of the vampire’s next turn.

***Vampire Weakness.*** The vampire has these weaknesses:

- **Forbiddance.** The vampire can't enter a residence without an invitation from an occupant.
- **Stake to the Heart.** If a wooden stake is driven into the vampire's heart while the vampire is [[Paralyzed]] and at 0 Hit Points, it is destroyed.

### Actions

***Multiattack.*** The vampire makes two Claw attacks and uses Cursing Bite.

***Claw.*** *Melee Attack Roll:* +9, reach 5 ft. *Hit:* 10 (2d4 + 5) Slashing damage. If the target is a Medium or smaller creature, it has the [[Grappled]] condition (escape DC 13) from one of two claws.

***Cursing Bite.*** *Constitution Saving Throw:* DC 16, one creature within 5 feet that is willing or that has the [[Grappled]], [[Incapacitated]], or [[Restrained]] condition. *Failure:* 7 (1d4 + 5) Piercing damage plus 10 (3d6) Necrotic damage. And the target is cursed. While cursed, the target can't regain hit points, and its hit points maximum decreases by 10 (3d6) for every 24 hours that elapse. If the curse reduces the target's hit point maximum to 0, the target dies, and it becomes a [[Vampire Spawn]]. The curse lasts until removed by the remove curse spell or other magic.

***Innate Spellcasting.*** The vampire casts one of the following spells requiring no components, using Charisma as the spellcasting ability (spell save DC 16):

**At will:** [[Command]], [[Detect Thoughts]], [[04) Backlink Glossary/Spells/Level 2/Darkness|Darkness]].
**2/day each:** [[Blight]], [[Fly]], [[Insect Plague]]
**1/day each:** [[Control Weather]]

### Bonus Actions
***Deathless Agility.*** The vampire takes the [[Dash]] or [[Disengage]] action.

***Shape-Shift.*** If the vampire isn’t in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.), or it returns to its vampire form. Anything it is wearing transforms with it. While in bat form, the vampire can’t speak. Its game statistics, other than its size and Speed, are unchanged.