---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Spawn
>
> *Medium or Small Undead, Neutral Evil*
>
> | |
> | - |
>
> **AC** 16
> **Initiative** +3 (13)
> **HP** 90 (12d8 + 36)
> **Speed** 30 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 21 | +5 | +5 | **INT** | 11 | +0 | +0 |
> | **DEX** | 16 | +3 | +6 | **WIS** | 10 | +0 | +3 |
> | **CON** | 16 | +3 | +3 | **CHA** | 12 | +1 | +1 |
>
> **Skills** [[Perception]] +3, [[Stealth]] +6
> **Resistances** Bludgeoning, Piercing, Slashing
> **Immunities** Necrotic, Poison
> **Senses** [[Darkvision]] 60 ft.; [[Passive Perception]] 13
> **Languages** Common plus one other language
> **CR** 5 (XP 1,800; PB +3)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |

### Traits

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Dark Immunities.*** While not in sunlight, the vampire has immunity to bludgeoning, piercing, and slashing damage.

***Vampire Weakness.*** The vampire has these weaknesses:

- **Forbiddance.** The vampire can't enter a residence without an invitation from an occupant.
- **Stake to the Heart.** The vampire is destroyed if a weapon that deals Piercing damage is driven into the vampire's heart while the vampire has the [[Incapacitated]] condition.


### Actions

***Multiattack.*** The vampire makes two Claw attacks and uses Feral Bite.

***Claw.*** *Melee Attack Roll:* +8, reach 5 ft. *Hit:* 10 (2d4 + 5) Slashing damage. If the target is a Medium or smaller creature, it has the [[Grappled]] condition (escape DC 13) from one of two claws.

***Feral Bite.*** *Constitution Saving Throw:* DC 14, one creature within 5 feet that is willing or that has the [[Grappled]], [[Incapacitated]], or [[Restrained]] condition. *Failure:* 7 (1d4 + 5) Piercing damage plus 10 (3d6) Necrotic damage. The target's Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount.

### Bonus Actions
***Deathless Agility.*** The vampire takes the [[Dash]] or [[Disengage]] action.