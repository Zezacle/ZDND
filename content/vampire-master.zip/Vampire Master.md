---
tags:
  - creature
---

> [!infobox|left clean wmed static]
> # Vampire Master
>
> *Medium or Small Undead, Lawful Evil*
>
> | |
> | - |
>
> **AC** 18
> **Initiative** +14 (24)
> **HP** 241 (23d8 + 138)
> **Speed** 40 ft., [[Climbing|Climb]] 40 ft.
>
> | | | MOD | SAVE | | | MOD | SAVE |
> | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
> | **STR** | 18 | +4 | +4 | **INT** | 17 | +3 | +3 |
> | **DEX** | 18 | +4 | +9 | **WIS** | 15 | +2 | +7 |
> | **CON** | 23 | +6 | +11 | **CHA** | 18 | +4 | +9 |
>
> **Skills** [[Insight]] +7, [[Perception]] +7, [[Stealth]] +9
> **Immunities** Bludgeoning, Piercing, Slashing, Necrotic, Poison
> **Senses** [[Darkvision]] 120 ft.; [[Passive Perception]] 17
> **Languages** Common plus two other languages
> **CR** 14 (XP 11,500, or 13,000 in lair; PB +5)
>
> | |
> | - |
>
> **Habitat**
> **Treasure**
>
> | |
> | - |


### Traits

***Legendary Resistance (3/Day, or 4/Day in Lair).*** If the vampire fails a saving throw, it can choose to succeed instead.

> [!checks|no-title]
> -
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%

***Misty Escape.*** If the vampire is reduced to 0 Hit Points outside its resting place, it uses Shape-Shifts to become a [[Vampiric Mist]] (no action required). If it can't use Shape-Shift, it is destroyed.

***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.

***Unholy Regeneration.*** The vampire regains 20 hit points at the start of its turn if it has at least 1 hit point. If the vampire takes radiant damage this trait doesn’t function at the start of the vampire’s next turn.

***Vampire Weakness.*** The vampire has these weaknesses:

- **Forbiddance.** The vampire can't enter a residence without an invitation from an occupant.
- **Stake to the Heart.** If a wooden stake is driven into the vampire's heart while the vampire is [[Paralyzed]] and at 0 Hit Points, it is destroyed.

### Actions

***Multiattack.*** The vampire makes two Grave Strike attacks and uses Blood-Sucking Bite.

***Grave Strike.*** *Melee Attack Roll:* +10, reach 5 ft. *Hit:* 9 (1d8 + 5) Bludgeoning damage plus 10 (3d6) Necrotic damage. If the target is a Large or smaller creature, it has the [[Grappled]] condition (escape DC 18) from one of two hands.

***Blood-Sucking Bite.*** *Constitution Saving Throw:* DC 17, one creature within 5 feet that is willing or that has the [[Grappled]], [[Incapacitated]], or [[Restrained]] condition. *Failure:* 7 (1d4 + 5) Piercing damage plus 21 (5d8) Necrotic damage. The target's Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount. A Humanoid reduced to 0 Hit Points is killed. If the Humanoid is then buried rises the following sunset as a **Vampire Spawn** under the vampire's control.

### Bonus Actions

***Lost Reflections (Recharge 6).*** The vampire summons 4 (2d4) [[Vampiric Reflection|Vampiric Reflections]] that appear in unoccupied spaces within 30 feet of the vampire that it can see. These reflections act on the vampire's initiative.

***Charm (Recharge 5-6).*** The vampire casts *[[Charm Person]]*, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17), and the duration is 24 hours. The [[Charmed]] target is a willing recipient of the vampire's Bite, the damage of which doesn't end the spell. When the spell ends, the target is unaware it was Charmed by the vampire.

***Shape-Shift.*** If the vampire isn't in sunlight or running water, it shape-shifts into a [[Vampiric Bat]]. Anything it is wearing transforms with it. The [[Hit Points]], Legendary Actions, and Legendary Resistances of the vampire remain the same regardless of form.

Shape-Shift. If the vampire isn’t in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.), or it returns to its vampire form. Anything it is wearing transforms with it.

While in bat form, the vampire can’t speak. Its game statistics, other than its size and Speed, are unchanged.

While in mist form, the vampire can’t take any actions, speak, or manipulate objects. It is weightless and can enter an enemy’s space and stop there. If air can pass through a space, the mist can do so, but it can’t pass through liquid. It has Resistance to all damage, except the damage it takes from sunlight.



### Legendary Actions
*Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the vampire can expend a use to take one of the following actions. The vampire regains all expended uses at the start of each of its turns.*

> [!checks|no-title]
> -
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%
>  - [ ] %% %%

***Beguile. (1/Round)*** The vampire casts *[[Command]]*, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17).

***Shape Reflections (1/Round).*** The vampire makes a Grave Strike attack and swaps places with a reflection it commands.

***Deathless Strike.*** The vampire moves up to half its Speed without provoking [[opportunity attacks]], and it makes one Grave Strike attack.